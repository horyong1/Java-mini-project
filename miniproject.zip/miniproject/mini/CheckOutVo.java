package project1st;

public class CheckOutVo {
	private String id;
	private String title;
	private String checkout_date;
	private String return_date;
	
	public CheckOutVo() {
		
	}
	
	public CheckOutVo(String id, String title, String checkout_date, String return_date) {
		
		this.id = id;
		this.title = title;
		this.checkout_date = checkout_date;
		this.return_date = return_date;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCheckout_date() {
		return checkout_date;
	}
	public void setCheckout_date(String checkout_date) {
		this.checkout_date = checkout_date;
	}
	public String getReturn_date() {
		return return_date;
	}
	public void setReturn_date(String return_date) {
		this.return_date = return_date;
	}
	
	
}
