package project1st;

public class Main {
	public static void main(String[]args) {
		Loginview lo = new Loginview();
		lo.mainView();
		
		
	}
}
